__version__ = '2.2.0rc3'
__git_version__ = '0.6.0-80373-gaad398b5e9'
